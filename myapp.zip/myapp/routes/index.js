var express = require('express');
var router = express.Router();
var fs = require('fs');
var mysql = require('mysql');
///
var pool = mysql.createPool({
    host     : '106.15.95.162',
    user     : 'root',
    password : 'sqltobe',
    database : 'test'
  });
  function handleDisconnect(){
	pool.getConnection(function(err, connection){
		if(err) console.log('Failed to connect Mysql');
		else{
			console.log('Succeed in connecting');
		}
	});
  }
	pool.on('error', function(err){
		if(err.code == 'PROTOCOL_CONNECTION_LOST'){
			Console.log('Lost connection to Mysql');
			setTimeout(function(){
				handleDisconnect();
			}, 5000);
		}
		else {
			throw err;
		}
	});
	handleDisconnect();
router.get('/index', function(req, res, next){
	console.log('get rec');
	var file = fs.createReadStream('../myapp/views/index.html');
	console.log('1');
	file.pipe(res);
	//res.send('1');
	console.log('2');
	//next();
});

router.post('/index', function(req, res){
   console.log('post rec');
   console.log(req.body);
   var data = req.body.id;
   var sql = 'select * from websites where id = ?';
   sql = mysql.format(sql, data);//查询数据库
   pool.query(sql, function (error, result) {
	if (error) throw error;
	var ans = JSON.parse(JSON.stringify(result));
	res.json(ans[0]);
	console.log(ans[0]);

	//var str = JSON.stringify(result);
	//res.type('text/javascript');
  });

  // res.json(req.body);
});

module.exports = router;
